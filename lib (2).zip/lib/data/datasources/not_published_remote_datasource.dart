import 'package:haraj_adan_app/core/network/api_client.dart';
import 'package:haraj_adan_app/core/network/endpoints.dart';
import '../models/not_published_model.dart';

abstract class NotPublishedRemoteDataSource {
  Future<List<NotPublishedModel>> fetchAds({required int userId});
}

class NotPublishedRemoteDataSourceImpl implements NotPublishedRemoteDataSource {
  final ApiClient apiClient;

  NotPublishedRemoteDataSourceImpl(this.apiClient);

  @override
  Future<List<NotPublishedModel>> fetchAds({required int userId}) async {
    final res = await apiClient.get(
      ApiEndpoints.userAdsByStatus(userId, 'unpublished'),
    );

    final list = _extractList(res);
    return list
        .whereType<Map<String, dynamic>>()
        .map(NotPublishedModel.fromJson)
        .toList();
  }

  List<dynamic> _extractList(dynamic res) {
    if (res is Map<String, dynamic>) {
      final data = res['data'];
      if (data is List) return data;
      if (data is Map && data['data'] is List) return data['data'] as List;
    }
    if (res is List) return res;
    return const [];
  }
}
