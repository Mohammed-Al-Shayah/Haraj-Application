class AppConstants {
  static const String ownerPhoneNumber = '+96605000000';
}
