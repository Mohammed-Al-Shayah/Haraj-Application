class ApiEndpoints {
  static String baseUrl = 'https://unityaid.net/haraj/api/v1';
  static String imageUrl = 'https://unityaid.net/haraj/uploads/';
  static String baseAPI = '$baseUrl/api';
  static String register = '$baseUrl/auth/register';
  static String login = '$baseUrl/auth/login';
  static String googleAuth = '$baseUrl/auth/google/redirect';
  static String verifyOtp = '$baseUrl/auth/verify-otp';
  static String resendOtp = '$baseUrl/auth/resend-otp';
  static String logout = '$baseUrl/auth/logout';
  static String banners = '$baseUrl/banners';
  static String adsHome = '$baseUrl/ads/home';
  static String categoriesHome = '$baseUrl/categories/home-page-menu';
}
