import '../../domain/entities/ad_entity.dart';

class AdModel extends AdEntity {
  AdModel({
    required super.id,
    required super.imageUrl,
    required super.title,
    required super.location,
    required super.price,
    required super.likesCount,
    required super.commentsCount,
    required super.createdAt,
    required super.latitude,
    required super.longitude,
  });

  factory AdModel.fromJson(Map<String, dynamic> json) {
    return AdModel(
      id: json['id'],
      imageUrl: json['imageUrl'],
      title: json['title'],
      location: json['location'],
      price: json['price'].toDouble(),
      likesCount: json['likesCount'],
      commentsCount: json['commentsCount'],
      createdAt: json['createdAt'],
      latitude: json['latitude'].toDouble(),
      longitude: json['longitude'].toDouble(),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'imageUrl': imageUrl,
    'title': title,
    'location': location,
    'price': price,
    'likesCount': likesCount,
    'commentsCount': commentsCount,
    'createdAt': createdAt,
    'latitude': latitude,
    'longitude': longitude,
  };
}
