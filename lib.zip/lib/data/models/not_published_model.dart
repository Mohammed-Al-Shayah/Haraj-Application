import '../../domain/entities/not_published_entity.dart';

class NotPublishedModel extends NotPublishedEntity {
  NotPublishedModel({
    required super.title,
    required super.location,
    required super.price,
    required super.imageUrl,
    super.status,
    super.latitude,
    super.longitude,
  });

  factory NotPublishedModel.fromJson(Map<String, dynamic> json) {
    return NotPublishedModel(
      title: json['title'],
      location: json['location'],
      price: json['price'],
      imageUrl: json['image'],
      status: json['status'],
      latitude: json['latitude'],
      longitude: json['longitude'],
    );
  }
}
