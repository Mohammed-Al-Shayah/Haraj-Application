import '../../domain/entities/shopping_ad_entity.dart';

class ShoppingAdModel {
  final String id;
  final String imageUrl;
  final String title;
  final String location;
  final double price;

  ShoppingAdModel({
    required this.id,
    required this.imageUrl,
    required this.title,
    required this.location,
    required this.price,
  });

  factory ShoppingAdModel.fromJson(Map<String, dynamic> json) {
    return ShoppingAdModel(
      id: json['id'],
      imageUrl: json['imageUrl'],
      title: json['title'],
      location: json['location'],
      price: json['price'].toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'imageUrl': imageUrl,
      'title': title,
      'location': location,
      'price': price,
    };
  }

  ShoppingAdEntity toEntity() {
    return ShoppingAdEntity(
      id: id,
      imageUrl: imageUrl,
      title: title,
      location: location,
      price: price,
    );
  }
}
