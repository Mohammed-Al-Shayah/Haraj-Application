import '../../domain/entities/favourite_ads_entity.dart';

class FavouriteAdsModel extends FavouriteAdsEntity {
  FavouriteAdsModel({
    required super.title,
    required super.location,
    required super.price,
    required super.imageUrl,
  });

  factory FavouriteAdsModel.fromJson(Map<String, dynamic> json) {
    return FavouriteAdsModel(
      title: json['title'],
      location: json['location'],
      price: json['price'],
      imageUrl: json['image'],
    );
  }
}
