import '../models/shopping_ad_model.dart';

abstract class ShoppingAdRemoteDataSource {
  Future<List<ShoppingAdModel>> getShoppingAds();
}

class ShoppingAdRemoteDataSourceImpl implements ShoppingAdRemoteDataSource {
  @override
  Future<List<ShoppingAdModel>> getShoppingAds() async {
    await Future.delayed(const Duration(seconds: 1));

    final imageUrls = [
      'https://i.pinimg.com/736x/9d/6a/f4/9d6af458c25077758d1560a37551808a.jpg',
      'https://i.pinimg.com/736x/70/22/f8/7022f8b989233b0490652e4a2040c4b3.jpg',
      'https://i.pinimg.com/736x/5e/6d/61/5e6d61a2f5be64785ad5546eaec3404e.jpg',
      'https://i.pinimg.com/736x/e6/a3/29/e6a329e659b59e0dca6603efec88e42a.jpg',
    ];

    final titles = [
      'Modern Office Desk',
      'Luxury Chair Set',
      'Wooden Book Shelf',
      'Glass Coffee Table',
    ];

    final locations = [
      'Adan, Yemen',
      'Sana\'a, Yemen',
      'Taiz, Yemen',
      'Ibb, Yemen',
    ];

    final prices = [320.0, 450.0, 290.0, 510.0];

    return List.generate(50, (index) {
      final i = index % 4;
      return ShoppingAdModel(
        id: '${index + 1}',
        imageUrl: imageUrls[i],
        title: titles[i],
        location: locations[i],
        price: prices[i],
      );
    });
  }
}
