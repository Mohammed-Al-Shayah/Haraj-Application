import 'package:dio/dio.dart';
import 'package:haraj_adan_app/core/network/endpoints.dart';

import '../models/ads/add_model.dart';

class AdsRepository {
  final Dio _dio;

  AdsRepository(this._dio);

  Future<List<AdModel>> getAllAds() async {
    try {
      final res = await _dio.get(ApiEndpoints.adsHome);

      if (res.statusCode == 200 && res.data['data'] != null) {
        final ads =
            (res.data['data'] as List)
                .map((json) => AdModel.fromJson(json))
                .toList();
        return ads;
      } else {
        throw Exception("Invalid response format");
      }
    } catch (e) {
      rethrow;
    }
  }
}
