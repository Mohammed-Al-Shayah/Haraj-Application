import 'package:dio/dio.dart';
import 'package:haraj_adan_app/core/network/endpoints.dart';
import 'package:haraj_adan_app/features/home/models/category.model.dart';

class CategoriesRepository {
  final Dio _dio;

  CategoriesRepository(this._dio);

  Future<List<CategoryModel>> getAllCategories() async {
    try {
      final res = await _dio.get(ApiEndpoints.categoriesHome);

      if (res.statusCode == 200 && res.data['data'] != null) {
        final list = res.data['data'] as List;
        return list.map((e) => CategoryModel.fromJson(e)).toList();
      } else {
        throw Exception("Invalid response format");
      }
    } on DioException catch (e) {
      final message =
          e.response?.data['message'] ?? e.message ?? 'Unknown error';
      throw Exception("Failed to load categories: $message");
    } catch (e) {
      throw Exception("Unexpected error: $e");
    }
  }
}
