import 'package:haraj_adan_app/features/home/models/ads/ad_attribute_model.dart';
import 'package:haraj_adan_app/features/home/models/ads/ad_featured_history_model.dart';
import 'package:haraj_adan_app/features/home/models/ads/ad_image_model.dart';

class AdModel {
  final int id;
  final int userId;
  final String title;
  final String titleEn;
  final String price;
  final DateTime created;
  final DateTime updated;
  final List<AdFeaturedHistoryModel> featuredHistory;
  final List<AdImageModel> images;
  final List<AdAttributeModel> attributes;

  AdModel({
    required this.id,
    required this.userId,
    required this.title,
    required this.titleEn,
    required this.price,
    required this.created,
    required this.updated,
    required this.featuredHistory,
    required this.images,
    required this.attributes,
  });

  factory AdModel.fromJson(Map<String, dynamic> json) {
    return AdModel(
      id: json['id'] ?? 0,
      userId: json['user_id'] ?? 0,
      title: json['title'] ?? '',
      titleEn: json['title_en'] ?? '',
      price: json['price']?.toString() ?? '',
      created: DateTime.parse(json['created']),
      updated: DateTime.parse(json['updated']),
      featuredHistory:
          (json['ad_featured_history'] as List<dynamic>?)
              ?.map((e) => AdFeaturedHistoryModel.fromJson(e))
              .toList() ??
          [],
      images:
          (json['ads_images'] as List<dynamic>?)
              ?.map((e) => AdImageModel.fromJson(e))
              .toList() ??
          [],
      attributes:
          (json['ad_attributes'] as List<dynamic>?)
              ?.map((e) => AdAttributeModel.fromJson(e))
              .toList() ??
          [],
    );
  }
}
