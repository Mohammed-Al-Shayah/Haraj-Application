import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/home_controller.dart';

extension HomeCategoriesExtension on HomeController {
  Future<void> loadCategories() async {
    try {
      isLoadingCategories.value = true;
      final result = await categoriesRepository.getAllCategories();
      categories.assignAll(result);
    } catch (e) {
      Get.snackbar(
        'خطأ',
        e.toString(),
        backgroundColor: const Color(0xFFE53935),
        colorText: const Color(0xFFFFFFFF),
      );
    } finally {
      isLoadingCategories.value = false;
    }
  }
}
