import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:haraj_adan_app/features/home/controllers/all_featured_ext_controller.dart';
import 'package:haraj_adan_app/features/home/controllers/banner_controller.dart';
import 'package:haraj_adan_app/features/home/controllers/categories_ext_controller.dart';
import 'package:haraj_adan_app/features/home/models/category.model.dart';
import 'package:haraj_adan_app/features/home/repo/ads_repository.dart';
import 'package:haraj_adan_app/features/home/repo/categories_repo.dart';
import 'package:haraj_adan_app/features/subcategories/api/banner_api.dart';
import 'package:haraj_adan_app/features/subcategories/models/banner_model.dart';
import '../../../domain/entities/category_entity.dart';
import '../../../domain/entities/featured_ad_entity.dart';
import '../../../domain/entities/shopping_ad_entity.dart';
import '../../../domain/repositories/category_repository.dart';
import '../../../domain/repositories/featured_ad_repository.dart';
import '../../../domain/repositories/shopping_ad_repository.dart';
import '../models/ads/add_model.dart';

class HomeController extends GetxController {
  final CategoryRepository? categoryRepository;
  final FeaturedAdRepository? featuredAdRepository;
  final ShoppingAdRepository? shoppingAdRepository;

  HomeController({
    this.categoryRepository,
    this.featuredAdRepository,
    this.shoppingAdRepository,
  });

  /// Category variables
  var staticCategories = <CategoryEntity>[].obs;
  var isLoadingStaticCategories = true.obs;

  /// Featured Ads variables
  var featuredAds = <FeaturedAdEntity>[].obs;
  var isLoadingFeaturedAds = true.obs;
  var isLoadingList = <bool>[].obs;

  /// Shopping Ads variables
  var shoppingAds = <ShoppingAdEntity>[].obs;
  var isLoadingShoppingAds = true.obs;
  var isLoadingShoppingList = <bool>[].obs;

  /// Banner variables
  final bannerApi = BannerApi();
  var banners = <BannerModel>[].obs;
  var isLoadingBanners = true.obs;

  /// Ads Home variables
  final AdsRepository repository = AdsRepository(Dio());
  var ads = <AdModel>[].obs;
  var isLoadingAds = false.obs;

  /// Categories variables
  final CategoriesRepository categoriesRepository = CategoriesRepository(Dio());
  var categories = <CategoryModel>[].obs;
  var isLoadingCategories = false.obs;

  @override
  void onInit() {
    super.onInit();
    if (categoryRepository != null) {
      loadStaticCategories();
    }
    if (featuredAdRepository != null) {
      loadFeaturedAds();
    }
    if (shoppingAdRepository != null) {
      loadShoppingAds();
    }
    loadBanners();
    loadAds();
    loadCategories();
  }

  /// Load categories if repository exists
  void loadStaticCategories() {
    if (categoryRepository == null) return;

    isLoadingStaticCategories(true);
    categoryRepository!
        .getCategories()
        .then((categories) => staticCategories.value = categories)
        .catchError((_) {
      Get.snackbar('Error', 'Failed to load categories');
    }).whenComplete(() {
      isLoadingStaticCategories(false);
    });
  }

  /// Load featured ads if repository exists
  Future<void> loadFeaturedAds() async {
    if (featuredAdRepository == null) return;

    try {
      isLoadingFeaturedAds(true);
      final ads = await featuredAdRepository!.getFeaturedAds();
      featuredAds.assignAll(ads);
      isLoadingList.assignAll(List<bool>.filled(ads.length, true));
      _simulateItemLoading();
    } catch (e) {
      Get.snackbar('Error', 'Failed to load featured ads');
    } finally {
      isLoadingFeaturedAds(false);
    }
  }

  /// Per-item loading animation
  void _simulateItemLoading() {
    for (int i = 0; i < featuredAds.length; i++) {
      Future.delayed(Duration(milliseconds: 300 * i), () {
        isLoadingList[i] = false;
        isLoadingList.refresh();
      });
    }
  }

  /// Load shopping ads if repository exists
  Future<void> loadShoppingAds() async {
    if (shoppingAdRepository == null) return;
    try {
      isLoadingShoppingAds(true);
      final ads = await shoppingAdRepository!.getShoppingAds();
      shoppingAds.assignAll(ads);
      isLoadingShoppingList.assignAll(List<bool>.filled(ads.length, true));
      _simulateShoppingItemLoading();
    } catch (e) {
      Get.snackbar('Error', 'Failed to load shopping ads');
    } finally {
      isLoadingShoppingAds(false);
    }
  }

  /// Per-item shopping loading animation
  void _simulateShoppingItemLoading() {
    for (int i = 0; i < shoppingAds.length; i++) {
      Future.delayed(Duration(milliseconds: 300 * i), () {
        isLoadingShoppingList[i] = false;
        isLoadingShoppingList.refresh();
      });
    }
  }
}
