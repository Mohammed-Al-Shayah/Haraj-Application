import 'package:image_picker/image_picker.dart';
import 'package:get/get.dart';
import 'dart:developer';
import 'dart:io';

class DepositController extends GetxController {
  Rx<File?> uploadedFile = Rx<File?>(null);
  RxString price = ''.obs;

  final ImagePicker _picker = ImagePicker();

  Future<void> pickImage() async {
    final picked = await _picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      uploadedFile.value = File(picked.path);
    }
  }

  void updatePrice(String value) {
    price.value = value;
  }

  void submit() {
    if (uploadedFile.value == null || price.value.isEmpty) {
      Get.snackbar("Error", "Please upload an invoice and enter the amount");
      return;
    }
    log("Image Path: ${uploadedFile.value!.path}");
    log("Price: ${price.value}");
  }
}
