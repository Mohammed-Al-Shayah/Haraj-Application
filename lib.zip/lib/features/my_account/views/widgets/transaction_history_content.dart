import 'package:flutter/material.dart';
import '../../../../core/theme/strings.dart';
import '../../../../core/theme/typography.dart';

class TransactionHistoryContent extends StatelessWidget {
  const TransactionHistoryContent({super.key});

  @override
  Widget build(BuildContext context) {
    final items = List.generate(10, (index) => index);
    final statuses = ['Complete', 'Pending', 'Canceled'];
    final colors = [Colors.green, Colors.orange, Colors.red];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(AppStrings.transactionHistory, style: AppTypography.semiBold18),
          const SizedBox(height: 12),
          ListView.builder(
            itemCount: items.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              final isDeposit = index % 2 == 0;
              final statusIndex = index % 3;

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isDeposit ? 'Deposit Received' : 'Item Purchased',
                          style: AppTypography.semiBold14,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Jun 17, 2025 • 10:3$index AM',
                          style: AppTypography.normal12.copyWith(
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),

                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          isDeposit ? '+\$50.00' : '-\$19.99',
                          style: AppTypography.medium12.copyWith(
                            color: isDeposit ? Colors.green : Colors.red,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: colors[statusIndex].withAlpha(
                              (0.1 * 255).toInt(),
                            ),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            statuses[statusIndex],
                            style: AppTypography.medium10.copyWith(
                              color: colors[statusIndex],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
