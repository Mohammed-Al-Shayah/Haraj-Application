import 'package:get/get.dart';

class AdDetailsController extends GetxController {}