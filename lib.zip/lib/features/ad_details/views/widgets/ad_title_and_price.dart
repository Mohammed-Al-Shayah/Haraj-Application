import 'package:flutter/material.dart';
import 'package:haraj_adan_app/core/theme/color.dart';
import 'package:haraj_adan_app/core/theme/typography.dart';

class AdTitleAndPrice extends StatelessWidget {
  const AdTitleAndPrice({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Istana Apartments',
            style: AppTypography.semiBold20,
          ),
          Text(
            "\$5,000",
            style: AppTypography.semiBold18.copyWith(color: AppColors.primary),
          ),
        ],
      ),
    );
  }
}
