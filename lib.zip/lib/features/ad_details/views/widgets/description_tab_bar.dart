import 'package:flutter/material.dart';
import 'package:haraj_adan_app/core/theme/color.dart';
import 'package:haraj_adan_app/core/theme/strings.dart';
import 'package:haraj_adan_app/core/theme/typography.dart';

class DescriptionTabBar extends StatelessWidget {
  const DescriptionTabBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(AppStrings.descriptionText, style: AppTypography.bold16),
          const SizedBox(height: 16.0),
          Text(
            "Welcome to Skyline Haven Apartments, where luxury meets convenience. This stunning 2-bedroom, "
            "2-bathroom apartment offers 1,200 sq. ft. of beautifully designed living space. With floor-to-ceiling windows, enjoy breathtaking city views from every room.",
            style: AppTypography.normal14.copyWith(color: AppColors.black75),
          ),
          const SizedBox(height: 16.0),
          Text(
            "Welcome to Skyline Haven Apartments, where luxury meets convenience. This stunning 2-bedroom.",
            style: AppTypography.normal14.copyWith(color: AppColors.black75),
          ),
        ],
      ),
    );
  }
}
