import 'package:flutter/material.dart';
import 'package:haraj_adan_app/core/theme/color.dart';
import '../../../../core/theme/strings.dart';
import '../../../../core/theme/typography.dart';

class QuestionCard extends StatelessWidget {
  const QuestionCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 2,
          itemBuilder: (context, index) {
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const CircleAvatar(radius: 23.0),
                      const SizedBox(width: 10.0),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text("Ahmed", style: AppTypography.bold16),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                const Icon(
                                  Icons.watch_later_outlined,
                                  size: 14,
                                  color: AppColors.gray500,
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  '2 ${AppStrings.hoursAgo}',
                                  style: AppTypography.normal14.copyWith(
                                    color: AppColors.gray500,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              "Welcome! Please enter your question below and we'll get back to you shortly.",
                              style: AppTypography.normal12,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                if (index != 1) ...[
                  const SizedBox(height: 16),
                  Divider(color: Colors.grey.shade300),
                ],
              ],
            );
          },
        ),
      ],
    );
  }
}
