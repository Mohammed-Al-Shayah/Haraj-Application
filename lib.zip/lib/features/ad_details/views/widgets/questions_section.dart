import 'package:flutter/material.dart';
import 'package:haraj_adan_app/core/theme/strings.dart';
import 'package:haraj_adan_app/core/theme/typography.dart';
import 'package:haraj_adan_app/features/ad_details/views/widgets/question_card.dart';
import '../../../../core/theme/color.dart';
import '../../../../core/widgets/input_field.dart';

class QuestionsSection extends StatelessWidget {
  const QuestionsSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.questionSectionTitle,
          style: AppTypography.bold14,
        ),
        const SizedBox(height: 9),
        Text(
          AppStrings.questionSectionSubTitle,
          style: AppTypography.normal12,
        ),
        const SizedBox(height: 16),
        const QuestionCard(),
        const SizedBox(height: 16),
        Divider(color: Colors.grey.shade300),
        const SizedBox(height: 24),
        Row(
          children: [
            Expanded(
              child: InputField(
                hintText: AppStrings.questionHintText,
                keyboardType: TextInputType.text,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              height: 50,
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(12),
              ),
              child: IconButton(
                icon: const Icon(
                  Icons.send,
                  color: Colors.white,
                  size: 24,
                ),
                onPressed: () {},
              ),
            ),
          ],
        ),
      ],
    );
  }
}
