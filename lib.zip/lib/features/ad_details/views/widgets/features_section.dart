import 'package:flutter/material.dart';
import 'package:haraj_adan_app/core/theme/strings.dart';
import 'package:haraj_adan_app/core/theme/typography.dart';
import 'package:haraj_adan_app/features/ad_details/views/widgets/feature_row.dart';

class FeaturesSection extends StatelessWidget {
  const FeaturesSection({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.featuresText,
          style: AppTypography.semiBold16,
        ),
        const SizedBox(height: 7.0),
        Column(
          children: [
            FeatureRow(
              label: AppStrings.intendedUseText,
              value: "Grocery Store",
            ),
            FeatureRow(
              label: AppStrings.generalSpecificationsText,
              value: AppStrings.unspecifiedText,
            ),
            FeatureRow(
              label: AppStrings.nearnessText,
              value: AppStrings.unspecifiedText,
            ),
            FeatureRow(
              label: AppStrings.viewText,
              value: AppStrings.unspecifiedText,
            ),
            FeatureRow(
              label: AppStrings.frontageText,
              value: AppStrings.unspecifiedText,
            ),
            FeatureRow(
              label: AppStrings.infrastructureText,
              value: AppStrings.unspecifiedText,
            ),
          ],
        ),
      ],
    );
  }
}
