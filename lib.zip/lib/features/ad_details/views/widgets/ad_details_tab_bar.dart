import 'package:flutter/material.dart';
import 'package:haraj_adan_app/core/theme/color.dart';
import 'package:haraj_adan_app/core/theme/strings.dart';
import 'package:haraj_adan_app/features/ad_details/views/widgets/questions_section.dart';
import 'package:haraj_adan_app/features/ad_details/views/widgets/detail_row.dart';
import 'package:haraj_adan_app/features/ad_details/views/widgets/features_section.dart';

class AdDetailsTabBar extends StatelessWidget {
  const AdDetailsTabBar({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DetailRow(
                label: AppStrings.priceText,
                value: "\$5,000",
                valueTextColor: AppColors.primary),
            DetailRow(label: AppStrings.listingDateText, value: "11/11/24"),
            DetailRow(
                label: AppStrings.adNumberText,
                value: "121006850",
                valueTextColor: AppColors.red),
            DetailRow(label: AppStrings.categoryText, value: "Commercial"),
            DetailRow(
                label: AppStrings.conditionText,
                value: "For Rent Store & Shop"),
            DetailRow(label: AppStrings.m2Text, value: "35"),
            DetailRow(label: AppStrings.ageOfBuildingText, value: "0"),
            DetailRow(label: AppStrings.classAndRoomNumberText, value: "0"),
            DetailRow(
                label: AppStrings.heatingText, value: "Merkezi (Pay Ölçer)"),
            DetailRow(label: AppStrings.buildingConditionText, value: "New"),
            DetailRow(label: AppStrings.duesText, value: "400"),
            DetailRow(label: AppStrings.depositText, value: "20,000"),
            DetailRow(
                label: AppStrings.titleDeedStatusText, value: "Condominium"),
            DetailRow(label: AppStrings.fromText, value: "Owner"),
            const SizedBox(height: 12.0),
            const FeaturesSection(),
            const QuestionsSection(),
          ],
        ),
      ),
    );
  }
}
