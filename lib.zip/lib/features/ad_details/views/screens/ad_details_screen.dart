import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:haraj_adan_app/core/theme/strings.dart';
import 'package:haraj_adan_app/core/widgets/main_bar.dart';
import 'package:haraj_adan_app/features/ad_details/views/widgets/bottom_navigation_action.dart';
import 'package:haraj_adan_app/features/ad_details/views/widgets/ad_details_image_slider.dart';
import 'package:haraj_adan_app/features/ad_details/views/widgets/ad_title_and_price.dart';
import 'package:haraj_adan_app/features/ad_details/views/widgets/tab_bar_views.dart';
import '../../../../core/theme/assets.dart';

class AdDetailsScreen extends GetView<AdDetailsScreen> {
  const AdDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MainBar(
        title: AppStrings.adDetailsTitle,
        customActions: [
          IconButton(
            onPressed: () {},
            icon: SvgPicture.asset(AppAssets.shareIcon),
          ),
          IconButton(
            onPressed: () {},
            icon: SvgPicture.asset(AppAssets.starIcon),
          ),
        ],
      ),
      bottomNavigationBar: const BottomNavigationAction(),
      body: const SingleChildScrollView(
        child: Column(
          children: [
            AdDetailsImageSlider(),
            AdTitleAndPrice(),
            TabBarViews(),
          ],
        ),
      ),
    );
  }
}
