import 'package:get/get.dart';

class PermissionsController extends GetxController {
  RxBool isMobileNotificationEnabled = false.obs;
  RxBool isMessageReadEnabled = false.obs;
}
