class MessageEntity {
  final String text;
  final bool isSender;

  MessageEntity({required this.text, required this.isSender});
}
